cd ai_help
./keygen.sh
cd key
rm -f file*
cd ..
./unifier.sh
