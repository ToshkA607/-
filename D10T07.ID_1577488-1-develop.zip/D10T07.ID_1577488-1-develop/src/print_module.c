#include "print_module.h"

#include <stdio.h>
#include <time.h>

char print_char(char ch) { return putchar(ch); }

void print_log(char (*print)(char), char *message) {
    time_t rawtime;
    struct tm *timeinfo;
    char time_str[9];

    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(time_str, sizeof(time_str), "%H:%M:%S", timeinfo);

    char *prefix = Log_prefix;
    while (*prefix) print(*prefix++);
    print(' ');
    char *t = time_str;
    while (*t) print(*t++);
    print(' ');
    while (*message) print(*message++);
}