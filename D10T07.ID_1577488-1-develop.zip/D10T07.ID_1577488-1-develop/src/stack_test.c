#include "stack.h"

#include <stdio.h>

void test_push(void) {
    printf("=== push TEST ===\n");
    stack *s = init();
    push(s, 10);
    push(s, 20);
    if (s->size == 2 && s->data[0] == 10 && s->data[1] == 20) {
        printf("push: SUCCESS\n");
    } else {
        printf("push: FAIL\n");
    }
    destroy(s);
}

void test_pop(void) {
    printf("=== pop TEST ===\n");
    stack *s = init();
    push(s, 10);
    push(s, 20);
    int val = pop(s);
    if (val == 20 && s->size == 1) {
        printf("pop: SUCCESS\n");
    } else {
        printf("pop: FAIL\n");
    }
    destroy(s);
}

int main() {
    test_push();
    test_pop();
    return 0;
}