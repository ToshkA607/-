#include <stdio.h>
#define LEN 100

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);
void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);

int main()
{
    int len1, len2;
    int num1[LEN], num2[LEN];
    

    len1 = 0;
    while (scanf("%d", &num1[len1]) == 1) {
        len1++;
        if (getchar() == '\n') break;
        if (len1 >= LEN) break;
    }
    

    len2 = 0;
    while (scanf("%d", &num2[len2]) == 1) {
        len2++;
        if (getchar() == '\n') break;
        if (len2 >= LEN) break;
    }
    
    if (len1 == 0 || len2 == 0) {
        printf("n/a\n");
        return 0;
    }
    
    int res_sum[LEN], res_sum_len;
    int res_sub[LEN], res_sub_len;
    
    sum(num1, len1, num2, len2, res_sum, &res_sum_len);
    sub(num1, len1, num2, len2, res_sub, &res_sub_len);
    

    for (int i = 0; i < res_sum_len; i++) {
        printf("%d", res_sum[i]);
        if (i < res_sum_len - 1) printf(" ");
    }
    printf("\n");
    

    if (res_sub_len == 0) {
        printf("n/a\n");
    } else {
        for (int i = 0; i < res_sub_len; i++) {
            printf("%d", res_sub[i]);
            if (i < res_sub_len - 1) printf(" ");
        }
        printf("\n");
    }
    
    return 0;
}

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length)
{
    int carry = 0;
    int i = len1 - 1, j = len2 - 1;
    int pos = 0;
    int temp[LEN];
    

    while (i >= 0 || j >= 0 || carry > 0) {
        int digit = carry;
        if (i >= 0) digit += buff1[i--];
        if (j >= 0) digit += buff2[j--];
        temp[pos++] = digit % 10;
        carry = digit / 10;
    }
    

    *result_length = pos;
    for (int k = 0; k < pos; k++) {
        result[k] = temp[pos - 1 - k];
    }
}

void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length)
{

    int is_bigger = 0;
    if (len1 > len2) {
        is_bigger = 1;
    } else if (len1 < len2) {
        is_bigger = 0;
    } else {

        for (int k = 0; k < len1; k++) {
            if (buff1[k] > buff2[k]) {
                is_bigger = 1;
                break;
            } else if (buff1[k] < buff2[k]) {
                is_bigger = 0;
                break;
            }
        }
    }
    
    if (!is_bigger) {
        *result_length = 0;
        return;
    }
    
    int borrow = 0;
    int i = len1 - 1, j = len2 - 1;
    int pos = 0;
    int temp[LEN];
    
    while (i >= 0 || j >= 0) {
        int digit = (i >= 0 ? buff1[i--] : 0) - borrow;
        if (j >= 0) digit -= buff2[j--];
        
        if (digit < 0) {
            digit += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
        temp[pos++] = digit;
    }
    
    while (pos > 1 && temp[pos - 1] == 0) {
        pos--;
    }
    
    *result_length = pos;
    for (int k = 0; k < pos; k++) {
        result[k] = temp[pos - 1 - k];
    }
}