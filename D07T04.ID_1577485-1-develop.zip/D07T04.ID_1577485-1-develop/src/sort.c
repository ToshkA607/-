#include <stdio.h>
#define NMAX 10

void input(int *a);
void output(int *a);
void sort(int *a);

int main()
{
    int data[NMAX];
    input(data);
    sort(data);
    output(data);
    return 0;
}

void input(int *a)
{
    for (int i = 0; i < NMAX; i++) {
        if (scanf("%d", &a[i]) != 1) {
            // Если ошибка ввода, просто выходим
            return;
        }
    }
}

void output(int *a)
{
    for (int i = 0; i < NMAX; i++) {
        printf("%d", a[i]);
        if (i < NMAX - 1) printf(" ");
    }
    printf("\n");
}

void sort(int *a)
{
    // Пузырьковая сортировка (простая и понятная)
    for (int i = 0; i < NMAX - 1; i++) {
        for (int j = 0; j < NMAX - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                // Обмен значений
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
}