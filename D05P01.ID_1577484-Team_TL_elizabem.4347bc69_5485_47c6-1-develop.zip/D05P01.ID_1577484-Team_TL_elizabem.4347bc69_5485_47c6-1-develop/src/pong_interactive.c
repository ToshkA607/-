#include <ncurses.h>
#include <stdlib.h>
#include <unistd.h>

static int ball_x = 40, ball_y = 12;
static int ball_dx = 1, ball_dy = 1;
static int player1_y = 11, player2_y = 11;
static int player1_score = 0, player2_score = 0;
static int player1_wins = 0, player2_wins = 0;
static int speed = 60;
static int base_speed = 60;
static int game_started = 0;
static int game_over = 0;
static int paused = 0;

void init_colors() {
    start_color();
    init_pair(1, COLOR_RED, COLOR_BLACK);
    init_pair(2, COLOR_GREEN, COLOR_BLACK);
    init_pair(3, COLOR_YELLOW, COLOR_BLACK);
    init_pair(4, COLOR_CYAN, COLOR_BLACK);
    init_pair(5, COLOR_MAGENTA, COLOR_BLACK);
}

void draw_field(WINDOW *win) {
    werase(win);
    
    // Верхняя граница
    wattron(win, COLOR_PAIR(3));
    for (int x = 0; x < 80; x++) {
        mvwaddch(win, 0, x, '#');
    }
    // Нижняя граница
    for (int x = 0; x < 80; x++) {
        mvwaddch(win, 25, x, '#');
    }
    // Левая граница
    for (int y = 0; y < 26; y++) {
        mvwaddch(win, y, 0, '#');
    }
    // Правая граница
    for (int y = 0; y < 26; y++) {
        mvwaddch(win, y, 79, '#');
    }
    wattroff(win, COLOR_PAIR(3));
    
    // Пунктирная линия
    for (int y = 1; y < 25; y++) {
        if (y % 2 == 0) {
            mvwaddch(win, y, 40, ':');
        }
    }
    
    // Ракетка игрока 1
    wattron(win, COLOR_PAIR(2));
    for (int i = 0; i < 3; i++) {
        mvwaddch(win, player1_y + i, 3, '|');
    }
    wattroff(win, COLOR_PAIR(2));
    
    // Ракетка игрока 2
    wattron(win, COLOR_PAIR(5));
    for (int i = 0; i < 3; i++) {
        mvwaddch(win, player2_y + i, 76, '|');
    }
    wattroff(win, COLOR_PAIR(5));
    
    // Мяч
    if (game_started && !game_over && !paused) {
        wattron(win, COLOR_PAIR(1));
        mvwaddch(win, ball_y, ball_x, 'O');
        wattroff(win, COLOR_PAIR(1));
    }
    
    // Счёт
    wattron(win, COLOR_PAIR(4));
    mvwprintw(win, 27, 35, "PONG");
    mvwprintw(win, 28, 18, "PLAYER 1");
    mvwprintw(win, 28, 52, "PLAYER 2");
    mvwprintw(win, 29, 23, "%d", player1_score);
    mvwprintw(win, 29, 55, "%d", player2_score);
    mvwprintw(win, 29, 39, "|");
    mvwprintw(win, 31, 18, "WINS: %d", player1_wins);
    mvwprintw(win, 31, 52, "WINS: %d", player2_wins);
    mvwprintw(win, 33, 20, "A  /  Z");
    mvwprintw(win, 34, 19, "UP  DOWN");
    mvwprintw(win, 33, 52, "K  /  M");
    mvwprintw(win, 34, 51, "UP  DOWN");
    mvwprintw(win, 36, 35, "SPEED: %d", base_speed);
    mvwprintw(win, 37, 35, "Q - EXIT");
    mvwprintw(win, 38, 32, "F - FASTER");
    mvwprintw(win, 39, 32, "S - SLOWER");
    mvwprintw(win, 40, 33, "P - PAUSE");
    wattroff(win, COLOR_PAIR(4));
    
    if (!game_started && !game_over) {
        wattron(win, COLOR_PAIR(1));
        mvwprintw(win, 20, 30, "PRESS SPACE TO START");
        wattroff(win, COLOR_PAIR(1));
    }
    
    if (paused && game_started) {
        wattron(win, COLOR_PAIR(1));
        mvwprintw(win, 20, 33, "PAUSED");
        mvwprintw(win, 21, 30, "PRESS P TO RESUME");
        wattroff(win, COLOR_PAIR(1));
    }
    
    wrefresh(win);
}

void update_ball() {
    if (!game_started || game_over || paused) return;
    
    ball_x += ball_dx;
    ball_y += ball_dy;
    
    if (ball_y <= 1) {
        ball_y = 1;
        ball_dy = 1;
    }
    if (ball_y >= 24) {
        ball_y = 24;
        ball_dy = -1;
    }
    
    if (ball_x == 4 && ball_y >= player1_y && ball_y < player1_y + 3) {
        ball_dx = 1;
    }
    
    if (ball_x == 75 && ball_y >= player2_y && ball_y < player2_y + 3) {
        ball_dx = -1;
    }
    
    if (ball_x <= 1) {
        player2_score++;
        if (player2_score >= 21) {
            player2_wins++;
            game_over = 1;
        }
        ball_x = 40; ball_y = 12;
        ball_dx = 1; ball_dy = 1;
        game_started = 0;
        napms(500);
    }
    
    if (ball_x >= 78) {
        player1_score++;
        if (player1_score >= 21) {
            player1_wins++;
            game_over = 1;
        }
        ball_x = 40; ball_y = 12;
        ball_dx = -1; ball_dy = 1;
        game_started = 0;
        napms(500);
    }
}

void reset_game() {
    player1_score = 0;
    player2_score = 0;
    ball_x = 40;
    ball_y = 12;
    ball_dx = 1;
    ball_dy = 1;
    game_started = 0;
    game_over = 0;
    paused = 0;
    speed = base_speed;
}

int show_menu() {
    clear();
    mvprintw(8, 25, "==================================");
    mvprintw(9, 25, "            PONG GAME             ");
    mvprintw(10, 25, "==================================");
    mvprintw(11, 25, "         SELECT SPEED             ");
    mvprintw(12, 25, "                                   ");
    mvprintw(13, 25, "      1. SLOW   (easy)            ");
    mvprintw(14, 25, "      2. NORMAL (medium)          ");
    mvprintw(15, 25, "      3. FAST   (hard)            ");
    mvprintw(16, 25, "      4. EXTREME (insane)         ");
    mvprintw(17, 25, "==================================");
    mvprintw(19, 25, "  Press 1, 2, 3 or 4              ");
    mvprintw(21, 20, "  TIP: Make terminal FULLSCREEN  ");
    mvprintw(22, 20, "       for best experience        ");
    refresh();
    
    int choice = getch();
    return choice;
}

int main() {
    initscr();
    cbreak();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
    
    if (has_colors() == FALSE) {
        endwin();
        printf("No color\n");
        return 1;
    }
    
    int speed_choice = show_menu();
    
    switch(speed_choice) {
        case '1': base_speed = 90; break;
        case '2': base_speed = 60; break;
        case '3': base_speed = 35; break;
        case '4': base_speed = 20; break;
        default: base_speed = 60;
    }
    
    speed = base_speed;
    
    init_colors();
    nodelay(stdscr, TRUE);
    
    WINDOW *win = newwin(43, 80, 0, 0);
    
    int ch;
    while (player1_wins < 3 && player2_wins < 3) {
        draw_field(win);
        
        ch = getch();
        
        if (ch == 'a' && player1_y > 1) player1_y--;
        if (ch == 'z' && player1_y < 22) player1_y++;
        if (ch == 'k' && player2_y > 1) player2_y--;
        if (ch == 'm' && player2_y < 22) player2_y++;
        
        if (ch == ' ' && !game_started && !game_over) {
            game_started = 1;
        }
        
        if (ch == 'p' || ch == 'P') {
            if (game_started && !game_over) {
                paused = !paused;
            }
        }
        
        if (ch == 'f' || ch == 'F') {
            if (base_speed > 10) {
                base_speed -= 5;
                speed = base_speed;
            }
        }
        if (ch == 's' || ch == 'S') {
            if (base_speed < 150) {
                base_speed += 5;
                speed = base_speed;
            }
        }
        
        if (ch == 'q') break;
        
        if (game_over) {
            napms(2000);
            reset_game();
        }
        
        update_ball();
        napms(speed);
    }
    
    clear();
    if (player1_wins >= 3) {
        mvprintw(15, 35, "PLAYER 1 WINS THE MATCH!");
    } else {
        mvprintw(15, 35, "PLAYER 2 WINS THE MATCH!");
    }
    refresh();
    napms(4000);
    
    endwin();
    return 0;
}