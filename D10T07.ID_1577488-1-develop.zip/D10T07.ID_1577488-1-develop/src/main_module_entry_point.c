#include <stdio.h>
#include <stdlib.h>

#include "documentation_module.h"
#include "print_module.h"

int main() {
    print_log(print_char, Module_load_success_message);

    char *documents[] = {Documents};
    int *availability = check_available_documentation_module(validate, Documents_count, documents[0],
                                                             documents[1], documents[2], documents[3]);

    printf("\n");
    for (int i = 0; i < Documents_count; i++) {
        printf("%-15s : %s\n", documents[i], availability[i] ? "available" : "unavailable");
    }

    free(availability);
    return 0;
}