#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "../data_libs/data_stat.h"
#include "../data_module/data_process.h"
#include "../yet_another_decision_module/decision.h"

int main() {
  double *data;
  int n;

  if (scanf("%d", &n) != 1 || n <= 0) {
    printf("n/a");
    return 0;
  }

  data = (double *)malloc(n * sizeof(double));
  if (data == NULL) {
    printf("n/a");
    return 0;
  }

  input(data, n);

  printf("LOAD DATA...\n");
  printf("RAW DATA:\n\t");
  output(data, n);

  printf("\nNORMALIZED DATA:\n\t");
  if (normalization(data, n)) {
    output(data, n);
  } else {
    printf("ERROR");
  }

  free(data);
  return 0;
}