# Руководство по работе с GitLab

## 1. Создание личного репозитория

1. Нажмите кнопку **"New project"** на главной странице GitLab
2. Выберите **"Create blank project"**
3. Укажите имя проекта
4. В разделе **"Initialize repository with"** отметьте:
   - ✅ `Enable README.md`
   - ✅ `Add .gitignore` (выберите шаблон, например, `Python` или `C`)
5. Нажмите **"Create project"**

![Создание репозитория](./screenshots/create_repo.png)

## 2. Создание веток

1. Перейдите в ваш проект
2. Нажмите на выпадающий список веток (по умолчанию `main` или `master`)
3. Введите имя новой ветки: `develop`
4. Нажмите **"Create branch"**
5. Аналогично создайте ветку `feature/example` от `develop`

![Создание веток](./screenshots/create_branches.png)

## 3. Создание Merge Request

1. Перейдите в раздел **"Merge Requests"** → **"New merge request"**
2. Выберите:
   - Source branch: `feature/example`
   - Target branch: `develop`
3. Нажмите **"Compare branches and continue"**
4. Заполните заголовок и описание
5. Назначьте ревьювера (опционально)
6. Нажмите **"Create merge request"**

![Создание MR](./screenshots/create_mr.png)

## 4. Создание задачи (Issue)

1. Перейдите в раздел **"Issues"** → **"New issue"**
2. Заполните:
   - **Title:** "Создать руководство по GitLab"
   - **Description:** описание задачи
3. Нажмите **"Create issue"**

### Добавление комментария к задаче

1. Откройте созданный Issue
2. Прокрутите вниз до поля комментария
3. Напишите комментарий, например: `Готово! Руководство создано.`
4. Нажмите **"Comment"**

![Создание Issue](./screenshots/create_issue.png)

