#include <stdio.h>
#include <stdlib.h>

void input(int **a, int *n);
void output(int *a, int n);
void sort(int *a, int n);

int main() {
    int *data = NULL;
    int n = 0;

    input(&data, &n);
    if (data == NULL) {
        printf("n/a");
        return 0;
    }

    sort(data, n);
    output(data, n);

    free(data);
    return 0;
}

void input(int **a, int *n) {
    if (scanf("%d", n) != 1 || *n <= 0) {
        *a = NULL;
        return;
    }

    *a = (int *)calloc(*n, sizeof(int));
    if (*a == NULL) {
        *a = NULL;
        return;
    }

    for (int i = 0; i < *n; i++) {
        if (scanf("%d", &(*a)[i]) != 1) {
            free(*a);
            *a = NULL;
            return;
        }
    }
}

void output(int *a, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d", a[i]);
        if (i < n - 1) printf(" ");
    }
}

void sort(int *a, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
}