#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

#define INIT_CAPACITY 10

stack *init(void) {
    stack *s = (stack *)malloc(sizeof(stack));
    if (s == NULL) return NULL;
    s->data = (int *)malloc(INIT_CAPACITY * sizeof(int));
    if (s->data == NULL) {
        free(s);
        return NULL;
    }
    s->size = 0;
    s->capacity = INIT_CAPACITY;
    return s;
}

void push(stack *s, int value) {
    if (s->size >= s->capacity) {
        s->capacity *= 2;
        s->data = (int *)realloc(s->data, s->capacity * sizeof(int));
    }
    s->data[s->size++] = value;
}

int pop(stack *s) {
    if (s->size == 0) return -1;
    return s->data[--s->size];
}

void destroy(stack *s) {
    if (s == NULL) return;
    free(s->data);
    free(s);
}