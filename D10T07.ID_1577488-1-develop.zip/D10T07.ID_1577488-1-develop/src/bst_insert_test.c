#include <stdio.h>
#include <stdlib.h>

#include "bst.h"

int compare(int a, int b) { return a - b; }

void print_tree_infix(t_btree *root) {
    if (root == NULL) return;
    print_tree_infix(root->left);
    printf("%d ", root->item);
    print_tree_infix(root->right);
}

int main() {
    printf("=== bstree_insert TEST ===\n");

    t_btree *root = bstree_create_node(10);
    bstree_insert(root, 5, compare);
    bstree_insert(root, 15, compare);
    bstree_insert(root, 3, compare);
    bstree_insert(root, 7, compare);

    printf("In-order traversal: ");
    print_tree_infix(root);
    printf("\n");

    free(root->left->left);
    free(root->left->right);
    free(root->left);
    free(root->right);
    free(root);

    return 0;
}