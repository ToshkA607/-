#include <stdio.h>
#include <stdlib.h>

#define MAX_STATIC 100

void input_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols);
void output_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols);
void row_max_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols, int* row_max);
void col_min_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols, int* col_min);

int** allocate_dynamic_ptr(int rows, int cols);
void free_dynamic_ptr(int** matrix, int rows);
void input_dynamic_ptr(int** matrix, int rows, int cols);
void output_dynamic_ptr(int** matrix, int rows, int cols);
void row_max_ptr(int** matrix, int rows, int cols, int* row_max);
void col_min_ptr(int** matrix, int rows, int cols, int* col_min);

int* allocate_dynamic_single(int rows, int cols);
void free_dynamic_single(int* matrix);
void input_dynamic_single(int* matrix, int rows, int cols);
void output_dynamic_single(int* matrix, int rows, int cols);
void row_max_single(int* matrix, int rows, int cols, int* row_max);
void col_min_single(int* matrix, int rows, int cols, int* col_min);

int** allocate_dynamic_segments(int rows, int cols);
void free_dynamic_segments(int** matrix, int rows);
void input_dynamic_segments(int** matrix, int rows, int cols);
void output_dynamic_segments(int** matrix, int rows, int cols);
void row_max_segments(int** matrix, int rows, int cols, int* row_max);
void col_min_segments(int** matrix, int rows, int cols, int* col_min);

int main() {
    int method, rows, cols;

    if (scanf("%d", &method) != 1 || method < 1 || method > 4) {
        printf("n/a");
        return 0;
    }

    if (scanf("%d %d", &rows, &cols) != 2 || rows <= 0 || cols <= 0) {
        printf("n/a");
        return 0;
    }

    int* row_max = (int*)malloc(rows * sizeof(int));
    int* col_min = (int*)malloc(cols * sizeof(int));
    if (row_max == NULL || col_min == NULL) {
        free(row_max);
        free(col_min);
        printf("n/a");
        return 0;
    }

    if (method == 1) {
        if (rows > MAX_STATIC || cols > MAX_STATIC) {
            printf("n/a");
            free(row_max);
            free(col_min);
            return 0;
        }
        int matrix[MAX_STATIC][MAX_STATIC];
        input_static(matrix, rows, cols);
        output_static(matrix, rows, cols);
        row_max_static(matrix, rows, cols, row_max);
        col_min_static(matrix, rows, cols, col_min);
    } else if (method == 2) {
        int** matrix = allocate_dynamic_ptr(rows, cols);
        if (matrix == NULL) {
            printf("n/a");
            free(row_max);
            free(col_min);
            return 0;
        }
        input_dynamic_ptr(matrix, rows, cols);
        output_dynamic_ptr(matrix, rows, cols);
        row_max_ptr(matrix, rows, cols, row_max);
        col_min_ptr(matrix, rows, cols, col_min);
        free_dynamic_ptr(matrix, rows);
    } else if (method == 3) {
        int* matrix = allocate_dynamic_single(rows, cols);
        if (matrix == NULL) {
            printf("n/a");
            free(row_max);
            free(col_min);
            return 0;
        }
        input_dynamic_single(matrix, rows, cols);
        output_dynamic_single(matrix, rows, cols);
        row_max_single(matrix, rows, cols, row_max);
        col_min_single(matrix, rows, cols, col_min);
        free_dynamic_single(matrix);
    } else if (method == 4) {
        int** matrix = allocate_dynamic_segments(rows, cols);
        if (matrix == NULL) {
            printf("n/a");
            free(row_max);
            free(col_min);
            return 0;
        }
        input_dynamic_segments(matrix, rows, cols);
        output_dynamic_segments(matrix, rows, cols);
        row_max_segments(matrix, rows, cols, row_max);
        col_min_segments(matrix, rows, cols, col_min);
        free_dynamic_segments(matrix, rows);
    }

    printf("\n");
    for (int i = 0; i < rows; i++) {
        printf("%d", row_max[i]);
        if (i < rows - 1) printf(" ");
    }
    printf("\n");
    for (int j = 0; j < cols; j++) {
        printf("%d", col_min[j]);
        if (j < cols - 1) printf(" ");
    }

    free(row_max);
    free(col_min);
    return 0;
}

void input_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void output_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

void row_max_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols, int* row_max) {
    for (int i = 0; i < rows; i++) {
        int max_val = matrix[i][0];
        for (int j = 1; j < cols; j++) {
            if (matrix[i][j] > max_val) max_val = matrix[i][j];
        }
        row_max[i] = max_val;
    }
}

void col_min_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols, int* col_min) {
    for (int j = 0; j < cols; j++) {
        int min_val = matrix[0][j];
        for (int i = 1; i < rows; i++) {
            if (matrix[i][j] < min_val) min_val = matrix[i][j];
        }
        col_min[j] = min_val;
    }
}

int** allocate_dynamic_ptr(int rows, int cols) {
    int** matrix = (int**)malloc(rows * sizeof(int*));
    if (matrix == NULL) return NULL;
    for (int i = 0; i < rows; i++) {
        matrix[i] = (int*)malloc(cols * sizeof(int));
        if (matrix[i] == NULL) {
            for (int k = 0; k < i; k++) free(matrix[k]);
            free(matrix);
            return NULL;
        }
    }
    return matrix;
}

void free_dynamic_ptr(int** matrix, int rows) {
    for (int i = 0; i < rows; i++) free(matrix[i]);
    free(matrix);
}

void input_dynamic_ptr(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void output_dynamic_ptr(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

void row_max_ptr(int** matrix, int rows, int cols, int* row_max) {
    for (int i = 0; i < rows; i++) {
        int max_val = matrix[i][0];
        for (int j = 1; j < cols; j++) {
            if (matrix[i][j] > max_val) max_val = matrix[i][j];
        }
        row_max[i] = max_val;
    }
}

void col_min_ptr(int** matrix, int rows, int cols, int* col_min) {
    for (int j = 0; j < cols; j++) {
        int min_val = matrix[0][j];
        for (int i = 1; i < rows; i++) {
            if (matrix[i][j] < min_val) min_val = matrix[i][j];
        }
        col_min[j] = min_val;
    }
}

int* allocate_dynamic_single(int rows, int cols) { return (int*)malloc(rows * cols * sizeof(int)); }

void free_dynamic_single(int* matrix) { free(matrix); }

void input_dynamic_single(int* matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i * cols + j]);
        }
    }
}

void output_dynamic_single(int* matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i * cols + j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

void row_max_single(int* matrix, int rows, int cols, int* row_max) {
    for (int i = 0; i < rows; i++) {
        int max_val = matrix[i * cols];
        for (int j = 1; j < cols; j++) {
            if (matrix[i * cols + j] > max_val) max_val = matrix[i * cols + j];
        }
        row_max[i] = max_val;
    }
}

void col_min_single(int* matrix, int rows, int cols, int* col_min) {
    for (int j = 0; j < cols; j++) {
        int min_val = matrix[j];
        for (int i = 1; i < rows; i++) {
            if (matrix[i * cols + j] < min_val) min_val = matrix[i * cols + j];
        }
        col_min[j] = min_val;
    }
}

int** allocate_dynamic_segments(int rows, int cols) {
    int* data = (int*)malloc(rows * cols * sizeof(int));
    if (data == NULL) return NULL;
    int** matrix = (int**)malloc(rows * sizeof(int*));
    if (matrix == NULL) {
        free(data);
        return NULL;
    }
    for (int i = 0; i < rows; i++) {
        matrix[i] = data + i * cols;
    }
    return matrix;
}

void free_dynamic_segments(int** matrix, int rows) {
    (void)rows;
    if (matrix == NULL) return;
    free(matrix[0]);
    free(matrix);
}

void input_dynamic_segments(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void output_dynamic_segments(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

void row_max_segments(int** matrix, int rows, int cols, int* row_max) {
    for (int i = 0; i < rows; i++) {
        int max_val = matrix[i][0];
        for (int j = 1; j < cols; j++) {
            if (matrix[i][j] > max_val) max_val = matrix[i][j];
        }
        row_max[i] = max_val;
    }
}

void col_min_segments(int** matrix, int rows, int cols, int* col_min) {
    for (int j = 0; j < cols; j++) {
        int min_val = matrix[0][j];
        for (int i = 1; i < rows; i++) {
            if (matrix[i][j] < min_val) min_val = matrix[i][j];
        }
        col_min[j] = min_val;
    }
}