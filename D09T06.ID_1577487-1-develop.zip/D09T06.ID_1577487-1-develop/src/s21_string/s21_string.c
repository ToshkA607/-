#include "s21_string.h"

#include <stddef.h>

s21_size_t s21_strlen(const char *str) {
  s21_size_t len = 0;
  while (str[len] != '\0') {
    len++;
  }
  return len;
}

int s21_strcmp(const char *str1, const char *str2) {
  while (*str1 && *str2 && *str1 == *str2) {
    str1++;
    str2++;
  }
  return *(unsigned char *)str1 - *(unsigned char *)str2;
}

char *s21_strcpy(char *dest, const char *src) {
  char *original_dest = dest;
  while ((*dest++ = *src++) != '\0') {
  }
  return original_dest;
}

char *s21_strcat(char *dest, const char *src) {
  char *original_dest = dest;
  while (*dest != '\0') {
    dest++;
  }
  while ((*dest++ = *src++) != '\0') {
  }
  return original_dest;
}

char *s21_strchr(const char *str, int c) {
  while (*str != '\0') {
    if (*str == (char)c) {
      return (char *)str;
    }
    str++;
  }
  if (c == '\0') {
    return (char *)str;
  }
  return NULL;
}

char *s21_strstr(const char *haystack, const char *needle) {
  if (*needle == '\0') {
    return (char *)haystack;
  }

  for (const char *h = haystack; *h != '\0'; h++) {
    const char *h_temp = h;
    const char *n_temp = needle;

    while (*h_temp != '\0' && *n_temp != '\0' && *h_temp == *n_temp) {
      h_temp++;
      n_temp++;
    }

    if (*n_temp == '\0') {
      return (char *)h;
    }
  }

  return NULL;
}