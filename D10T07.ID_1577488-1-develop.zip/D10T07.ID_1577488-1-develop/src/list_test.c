#include "list.h"

#include <stdio.h>

void test_add_door(void) {
    printf("=== add_door TEST ===\n");
    struct door door1 = {1, 0};
    struct node *root = init(door1);
    struct door door2 = {2, 0};
    add_door(root, door2);
    if (root->next != NULL && root->next->door.id == 2) {
        printf("add_door: SUCCESS\n");
    } else {
        printf("add_door: FAIL\n");
    }
    destroy(root);
}

void test_remove_door(void) {
    printf("=== remove_door TEST ===\n");
    struct door door1 = {1, 0};
    struct door door2 = {2, 0};
    struct node *root = init(door1);
    add_door(root, door2);
    struct node *to_remove = root->next;
    root = remove_door(to_remove, root);
    if (root->next == NULL && root->door.id == 1) {
        printf("remove_door: SUCCESS\n");
    } else {
        printf("remove_door: FAIL\n");
    }
    destroy(root);
}

int main() {
    test_add_door();
    test_remove_door();
    return 0;
}