#include "decision.h"

#include <math.h>

#include "../data_libs/data_stat.h"

int make_decision(double *data, int n) {
  if (n <= 0)
    return 0;

  double m = mean(data, n);
  double sigma = sqrt(variance(data, n));
  double max_val = max(data, n);
  double min_val = min(data, n);

  int three_sigma = (max_val <= m + 3 * sigma) && (min_val >= m - 3 * sigma);

  int mean_condition = (m >= GOLDEN_RATIO);

  return three_sigma && mean_condition;
}