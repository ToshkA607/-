#include <stdio.h>
#include <stdlib.h>

int input(int ***matrix, int *n, int *m);
void output(int **matrix, int n, int m);
int sum(int **matrix_first, int n_first, int m_first, int **matrix_second, int n_second, int m_second,
        int ***matrix_result, int *n_result, int *m_result);
int transpose(int **matrix, int n, int m, int ***matrix_result, int *n_result, int *m_result);
int mul(int **matrix_first, int n_first, int m_first, int **matrix_second, int n_second, int m_second,
        int ***matrix_result, int *n_result, int *m_result);

int main() {
    int operation;
    if (scanf("%d", &operation) != 1) {
        printf("n/a");
        return 0;
    }

    if (operation == 1) {
        int **matrix_first = NULL, **matrix_second = NULL;
        int n1, m1, n2, m2;

        if (input(&matrix_first, &n1, &m1) == 0 || input(&matrix_second, &n2, &m2) == 0) {
            printf("n/a");
            return 0;
        }

        if (n1 != n2 || m1 != m2) {
            printf("n/a");
            free(matrix_first[0]);
            free(matrix_first);
            free(matrix_second[0]);
            free(matrix_second);
            return 0;
        }

        int **matrix_result = NULL;
        int n_res, m_res;
        if (sum(matrix_first, n1, m1, matrix_second, n2, m2, &matrix_result, &n_res, &m_res) == 0) {
            printf("n/a");
            return 0;
        }

        output(matrix_result, n_res, m_res);

        free(matrix_first[0]);
        free(matrix_first);
        free(matrix_second[0]);
        free(matrix_second);
        free(matrix_result[0]);
        free(matrix_result);
    } else if (operation == 2) {
        int **matrix_first = NULL, **matrix_second = NULL;
        int n1, m1, n2, m2;

        if (input(&matrix_first, &n1, &m1) == 0 || input(&matrix_second, &n2, &m2) == 0) {
            printf("n/a");
            return 0;
        }

        if (m1 != n2) {
            printf("n/a");
            free(matrix_first[0]);
            free(matrix_first);
            free(matrix_second[0]);
            free(matrix_second);
            return 0;
        }

        int **matrix_result = NULL;
        int n_res, m_res;
        if (mul(matrix_first, n1, m1, matrix_second, n2, m2, &matrix_result, &n_res, &m_res) == 0) {
            printf("n/a");
            return 0;
        }

        output(matrix_result, n_res, m_res);

        free(matrix_first[0]);
        free(matrix_first);
        free(matrix_second[0]);
        free(matrix_second);
        free(matrix_result[0]);
        free(matrix_result);
    } else if (operation == 3) {
        int **matrix = NULL;
        int n, m;

        if (input(&matrix, &n, &m) == 0) {
            printf("n/a");
            return 0;
        }

        int **matrix_result = NULL;
        int n_res, m_res;
        if (transpose(matrix, n, m, &matrix_result, &n_res, &m_res) == 0) {
            printf("n/a");
            return 0;
        }

        output(matrix_result, n_res, m_res);

        free(matrix[0]);
        free(matrix);
        free(matrix_result[0]);
        free(matrix_result);
    } else {
        printf("n/a");
    }

    return 0;
}

int input(int ***matrix, int *n, int *m) {
    if (scanf("%d %d", n, m) != 2 || *n <= 0 || *m <= 0) {
        return 0;
    }

    *matrix = (int **)malloc(*n * sizeof(int *));
    if (*matrix == NULL) return 0;

    int *data = (int *)malloc(*n * *m * sizeof(int));
    if (data == NULL) {
        free(*matrix);
        return 0;
    }

    for (int i = 0; i < *n; i++) {
        (*matrix)[i] = data + i * (*m);
    }

    for (int i = 0; i < *n; i++) {
        for (int j = 0; j < *m; j++) {
            if (scanf("%d", &(*matrix)[i][j]) != 1) {
                free(data);
                free(*matrix);
                return 0;
            }
        }
    }

    return 1;
}

void output(int **matrix, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            printf("%d", matrix[i][j]);
            if (j < m - 1) printf(" ");
        }
        if (i < n - 1) printf("\n");
    }
}

int sum(int **matrix_first, int n_first, int m_first, int **matrix_second, int n_second, int m_second,
        int ***matrix_result, int *n_result, int *m_result) {
    if (n_first != n_second || m_first != m_second) return 0;

    *n_result = n_first;
    *m_result = m_first;

    *matrix_result = (int **)malloc(*n_result * sizeof(int *));
    if (*matrix_result == NULL) return 0;

    int *data = (int *)malloc(*n_result * *m_result * sizeof(int));
    if (data == NULL) {
        free(*matrix_result);
        return 0;
    }

    for (int i = 0; i < *n_result; i++) {
        (*matrix_result)[i] = data + i * (*m_result);
    }

    for (int i = 0; i < *n_result; i++) {
        for (int j = 0; j < *m_result; j++) {
            (*matrix_result)[i][j] = matrix_first[i][j] + matrix_second[i][j];
        }
    }

    return 1;
}

int transpose(int **matrix, int n, int m, int ***matrix_result, int *n_result, int *m_result) {
    *n_result = m;
    *m_result = n;

    *matrix_result = (int **)malloc(*n_result * sizeof(int *));
    if (*matrix_result == NULL) return 0;

    int *data = (int *)malloc(*n_result * *m_result * sizeof(int));
    if (data == NULL) {
        free(*matrix_result);
        return 0;
    }

    for (int i = 0; i < *n_result; i++) {
        (*matrix_result)[i] = data + i * (*m_result);
    }

    for (int i = 0; i < *n_result; i++) {
        for (int j = 0; j < *m_result; j++) {
            (*matrix_result)[i][j] = matrix[j][i];
        }
    }

    return 1;
}

int mul(int **matrix_first, int n_first, int m_first, int **matrix_second, int n_second, int m_second,
        int ***matrix_result, int *n_result, int *m_result) {
    if (m_first != n_second) return 0;

    *n_result = n_first;
    *m_result = m_second;

    *matrix_result = (int **)malloc(*n_result * sizeof(int *));
    if (*matrix_result == NULL) return 0;

    int *data = (int *)malloc(*n_result * *m_result * sizeof(int));
    if (data == NULL) {
        free(*matrix_result);
        return 0;
    }

    for (int i = 0; i < *n_result; i++) {
        (*matrix_result)[i] = data + i * (*m_result);
    }

    for (int i = 0; i < *n_result; i++) {
        for (int j = 0; j < *m_result; j++) {
            (*matrix_result)[i][j] = 0;
            for (int k = 0; k < m_first; k++) {
                (*matrix_result)[i][j] += matrix_first[i][k] * matrix_second[k][j];
            }
        }
    }

    return 1;
}