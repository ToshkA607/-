#include "data_process.h"

#include <math.h>

#include "../data_libs/data_stat.h"

int normalization(double *data, int n) {
  if (n <= 0)
    return 0;

  double max_value = max(data, n);
  double min_value = min(data, n);
  double size = max_value - min_value;

  if (fabs(size) < EPS) {
    return 0;
  }

  for (int i = 0; i < n; i++) {
    data[i] = (data[i] - min_value) / size;
  }

  return 1;
}