#include <stdio.h>

int main() {
    int matrix[4][4] = {{87, 46, 57, 29}, {129, 156, 122, 141}, {143, 127, 107, 116}, {69, 78, 112, 101}};
    int vector[4] = {1, 2, 3, 4};
    int result[4];

    for (int i = 0; i < 4; i++) {
        result[i] = 0;
        for (int j = 0; j < 4; j++) {
            result[i] += matrix[i][j] * vector[j];
        }
    }

    for (int i = 0; i < 4; i++) {
        printf("%d", result[i]);
        if (i < 3) printf(" ");
    }

    return 0;
}