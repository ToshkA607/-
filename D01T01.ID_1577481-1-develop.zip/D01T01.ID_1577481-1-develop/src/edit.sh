#!/bin/bash

if [ $# -ne 3 ]; then
    echo "Usage: $0 <file> <old_string> <new_string>"
    exit 1
fi

file="$1"
old="$2"
new="$3"

if [ ! -f "$file" ]; then
    echo "Error: File '$file' not found"
    exit 1
fi

old_escaped=$(echo "$old" | sed 's/[\/&]/\\&/g')
new_escaped=$(echo "$new" | sed 's/[\/&]/\\&/g')
sed -i '' "s/$old_escaped/$new_escaped/g" "$file"

size=$(stat -f%z "$file")
date=$(date "+%Y-%m-%d %H:%M:%S")
sha=$(shasum -a 256 "$file" | cut -d' ' -f1)
echo "$file - $size - $date - $sha - sha256" >> files.log

echo "Done: replaced '$old' with '$new' in '$file'"

