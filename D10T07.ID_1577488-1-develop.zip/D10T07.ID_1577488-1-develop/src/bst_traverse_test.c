#include <stdio.h>
#include <stdlib.h>

#include "bst.h"

int compare(int a, int b) { return a - b; }

void print_int(int value) { printf("%d ", value); }

int main() {
    printf("=== BST Traverse TEST ===\n");

    t_btree *root = bstree_create_node(10);
    bstree_insert(root, 5, compare);
    bstree_insert(root, 15, compare);
    bstree_insert(root, 3, compare);
    bstree_insert(root, 7, compare);
    bstree_insert(root, 12, compare);
    bstree_insert(root, 18, compare);

    printf("Infix (sorted): ");
    bstree_apply_infix(root, print_int);
    printf("\n");

    printf("Prefix: ");
    bstree_apply_prefix(root, print_int);
    printf("\n");

    printf("Postfix: ");
    bstree_apply_postfix(root, print_int);
    printf("\n");

    // Очистка памяти (упрощённо)
    free(root->left->left);
    free(root->left->right);
    free(root->left);
    free(root->right->left);
    free(root->right->right);
    free(root->right);
    free(root);

    return 0;
}