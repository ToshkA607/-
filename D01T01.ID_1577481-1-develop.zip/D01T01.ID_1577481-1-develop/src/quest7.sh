git checkout -b key-branch
cp src/ai_help/main.key src/ai_help/main-2.key
git add src/ai_help/main-2.key
git commit -m "key-branch: add main-2.key copy"
git checkout -b feature/3-key
cp src/ai_help/main.key src/ai_help/main-3.key
git add src/ai_help/main-3.key
git commit -m "feature/3-key: add main-3.key copy"
git checkout key-branch
git merge feature/3-key
git checkout develop
git checkout -b release/1.0
git checkout develop
git merge key-branch
git checkout release/1.0
git merge develop
git push origin --all

