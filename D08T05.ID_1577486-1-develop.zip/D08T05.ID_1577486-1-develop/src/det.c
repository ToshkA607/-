#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double det(double **matrix, int n);
void input(double ***matrix, int *n);
void output(double d);

int main() {
    double **matrix = NULL;
    int n;

    input(&matrix, &n);
    if (matrix == NULL) {
        printf("n/a");
        return 0;
    }

    double d = det(matrix, n);
    output(d);

    free(matrix[0]);
    free(matrix);
    return 0;
}

void input(double ***matrix, int *n) {
    if (scanf("%d", n) != 1 || *n <= 0) {
        *matrix = NULL;
        return;
    }

    *matrix = (double **)malloc(*n * sizeof(double *));
    if (*matrix == NULL) return;

    double *data = (double *)malloc(*n * *n * sizeof(double));
    if (data == NULL) {
        free(*matrix);
        *matrix = NULL;
        return;
    }

    for (int i = 0; i < *n; i++) {
        (*matrix)[i] = data + i * (*n);
    }

    for (int i = 0; i < *n; i++) {
        for (int j = 0; j < *n; j++) {
            if (scanf("%lf", &(*matrix)[i][j]) != 1) {
                free(data);
                free(*matrix);
                *matrix = NULL;
                return;
            }
        }
    }
}

double det(double **matrix, int n) {
    if (n == 1) return matrix[0][0];
    if (n == 2) {
        return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
    }

    double result = 0.0;
    double **sub_matrix = (double **)malloc((n - 1) * sizeof(double *));
    double *sub_data = (double *)malloc((n - 1) * (n - 1) * sizeof(double));
    if (sub_matrix == NULL || sub_data == NULL) return 0;

    for (int i = 0; i < n - 1; i++) {
        sub_matrix[i] = sub_data + i * (n - 1);
    }

    for (int col = 0; col < n; col++) {
        int sub_i = 0;
        for (int i = 1; i < n; i++) {
            int sub_j = 0;
            for (int j = 0; j < n; j++) {
                if (j != col) {
                    sub_matrix[sub_i][sub_j] = matrix[i][j];
                    sub_j++;
                }
            }
            sub_i++;
        }
        double sign = (col % 2 == 0) ? 1.0 : -1.0;
        result += sign * matrix[0][col] * det(sub_matrix, n - 1);
    }

    free(sub_data);
    free(sub_matrix);
    return result;
}

void output(double d) { printf("%.6f", d); }