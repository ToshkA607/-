#include "s21_string.h"

#include <stdio.h>

void s21_strlen_test(void) {
  printf("=== s21_strlen TESTS ===\n");

  const char *test1 = "Hello";
  s21_size_t len1 = s21_strlen(test1);
  printf("Input: \"%s\"\nOutput: %lu\n", test1, len1);
  printf("Test result: %s\n\n", len1 == 5 ? "SUCCESS" : "FAIL");

  const char *test2 = "";
  s21_size_t len2 = s21_strlen(test2);
  printf("Input: \"%s\"\nOutput: %lu\n", test2, len2);
  printf("Test result: %s\n\n", len2 == 0 ? "SUCCESS" : "FAIL");

  const char *test3 = "Hello, World!";
  s21_size_t len3 = s21_strlen(test3);
  printf("Input: \"%s\"\nOutput: %lu\n", test3, len3);
  printf("Test result: %s\n\n", len3 == 13 ? "SUCCESS" : "FAIL");
}

void s21_strcmp_test(void) {
  printf("=== s21_strcmp TESTS ===\n");

  int result1 = s21_strcmp("abc", "abc");
  printf("Input: \"abc\" vs \"abc\"\nOutput: %d\n", result1);
  printf("Test result: %s\n\n", result1 == 0 ? "SUCCESS" : "FAIL");

  int result2 = s21_strcmp("abc", "abd");
  printf("Input: \"abc\" vs \"abd\"\nOutput: %d\n", result2);
  printf("Test result: %s\n\n", result2 < 0 ? "SUCCESS" : "FAIL");

  int result3 = s21_strcmp("abd", "abc");
  printf("Input: \"abd\" vs \"abc\"\nOutput: %d\n", result3);
  printf("Test result: %s\n\n", result3 > 0 ? "SUCCESS" : "FAIL");

  int result4 = s21_strcmp("", "");
  printf("Input: \"\" vs \"\"\nOutput: %d\n", result4);
  printf("Test result: %s\n\n", result4 == 0 ? "SUCCESS" : "FAIL");
}

void s21_strcpy_test(void) {
  printf("=== s21_strcpy TESTS ===\n");

  char dest1[50];
  s21_strcpy(dest1, "Hello");
  printf("Input: src=\"Hello\"\nOutput: \"%s\"\n", dest1);
  printf("Test result: %s\n\n",
         s21_strcmp(dest1, "Hello") == 0 ? "SUCCESS" : "FAIL");

  char dest2[50];
  s21_strcpy(dest2, "");
  printf("Input: src=\"\"\nOutput: \"%s\"\n", dest2);
  printf("Test result: %s\n\n",
         s21_strcmp(dest2, "") == 0 ? "SUCCESS" : "FAIL");

  char dest3[50];
  s21_strcpy(dest3, "Hello, World!");
  printf("Input: src=\"Hello, World!\"\nOutput: \"%s\"\n", dest3);
  printf("Test result: %s\n\n",
         s21_strcmp(dest3, "Hello, World!") == 0 ? "SUCCESS" : "FAIL");
}

void s21_strcat_test(void) {
  printf("=== s21_strcat TESTS ===\n");

  char dest1[50] = "Hello";
  s21_strcat(dest1, " World");
  printf("Input: dest=\"Hello\", src=\" World\"\nOutput: \"%s\"\n", dest1);
  printf("Test result: %s\n\n",
         s21_strcmp(dest1, "Hello World") == 0 ? "SUCCESS" : "FAIL");

  char dest2[50] = "";
  s21_strcat(dest2, "Hello");
  printf("Input: dest=\"\", src=\"Hello\"\nOutput: \"%s\"\n", dest2);
  printf("Test result: %s\n\n",
         s21_strcmp(dest2, "Hello") == 0 ? "SUCCESS" : "FAIL");

  char dest3[50] = "Hello";
  s21_strcat(dest3, "");
  printf("Input: dest=\"Hello\", src=\"\"\nOutput: \"%s\"\n", dest3);
  printf("Test result: %s\n\n",
         s21_strcmp(dest3, "Hello") == 0 ? "SUCCESS" : "FAIL");
}

void s21_strchr_test(void) {
  printf("=== s21_strchr TESTS ===\n");

  const char *str1 = "Hello, World!";
  char *result1 = s21_strchr(str1, 'W');
  printf("Input: str=\"%s\", c='W'\nOutput: \"%s\"\n", str1, result1);
  printf("Test result: %s\n\n",
         result1 != NULL && s21_strcmp(result1, "World!") == 0 ? "SUCCESS"
                                                               : "FAIL");

  const char *str2 = "Hello, World!";
  char *result2 = s21_strchr(str2, 'z');
  printf("Input: str=\"%s\", c='z'\nOutput: %s\n", str2,
         result2 == NULL ? "NULL" : result2);
  printf("Test result: %s\n\n", result2 == NULL ? "SUCCESS" : "FAIL");

  const char *str3 = "Hello, World!";
  char *result3 = s21_strchr(str3, '\0');
  printf("Input: str=\"%s\", c='\\0'\nOutput: \"%s\"\n", str3, result3);
  printf("Test result: %s\n\n",
         result3 != NULL && *result3 == '\0' ? "SUCCESS" : "FAIL");

  const char *str4 = "";
  char *result4 = s21_strchr(str4, 'a');
  printf("Input: str=\"%s\", c='a'\nOutput: %s\n", str4,
         result4 == NULL ? "NULL" : result4);
  printf("Test result: %s\n\n", result4 == NULL ? "SUCCESS" : "FAIL");
}

void s21_strstr_test(void) {
  printf("=== s21_strstr TESTS ===\n");

  const char *haystack1 = "Hello, World!";
  const char *needle1 = "World";
  char *result1 = s21_strstr(haystack1, needle1);
  printf("Input: haystack=\"%s\", needle=\"%s\"\nOutput: \"%s\"\n", haystack1,
         needle1, result1);
  printf("Test result: %s\n\n",
         result1 != NULL && s21_strcmp(result1, "World!") == 0 ? "SUCCESS"
                                                               : "FAIL");

  const char *haystack2 = "Hello, World!";
  const char *needle2 = "xyz";
  char *result2 = s21_strstr(haystack2, needle2);
  printf("Input: haystack=\"%s\", needle=\"%s\"\nOutput: %s\n", haystack2,
         needle2, result2 == NULL ? "NULL" : result2);
  printf("Test result: %s\n\n", result2 == NULL ? "SUCCESS" : "FAIL");

  const char *haystack3 = "Hello, World!";
  const char *needle3 = "";
  char *result3 = s21_strstr(haystack3, needle3);
  printf("Input: haystack=\"%s\", needle=\"\"\nOutput: \"%s\"\n", haystack3,
         result3);
  printf("Test result: %s\n\n",
         result3 != NULL && s21_strcmp(result3, haystack3) == 0 ? "SUCCESS"
                                                                : "FAIL");

  const char *haystack4 = "aaaaa";
  const char *needle4 = "aaa";
  char *result4 = s21_strstr(haystack4, needle4);
  printf("Input: haystack=\"%s\", needle=\"%s\"\nOutput: \"%s\"\n", haystack4,
         needle4, result4);
  printf("Test result: %s\n\n", result4 != NULL ? "SUCCESS" : "FAIL");

  const char *haystack5 = "";
  const char *needle5 = "abc";
  char *result5 = s21_strstr(haystack5, needle5);
  printf("Input: haystack=\"%s\", needle=\"%s\"\nOutput: %s\n", haystack5,
         needle5, result5 == NULL ? "NULL" : result5);
  printf("Test result: %s\n\n", result5 == NULL ? "SUCCESS" : "FAIL");

  const char *haystack6 = "abcabcabc";
  const char *needle6 = "abc";
  char *result6 = s21_strstr(haystack6, needle6);
  printf("Input: haystack=\"%s\", needle=\"%s\"\nOutput: \"%s\"\n", haystack6,
         needle6, result6);
  printf("Test result: %s\n\n",
         result6 != NULL && s21_strcmp(result6, "abcabcabc") == 0 ? "SUCCESS"
                                                                  : "FAIL");
}

int main() {
  s21_strlen_test();
  s21_strcmp_test();
  s21_strcpy_test();
  s21_strcat_test();
  s21_strchr_test();
  s21_strstr_test();
  return 0;
}