#include <stdio.h>
#include <math.h>
#define NMAX 30

int input(int *a, int *n);
double mean(int *a, int n);
double variance(int *a, int n);
int search(int *a, int n);

int main()
{
    int n, data[NMAX];
    if (input(data, &n) == 0) {
        printf("n/a\n");
        return 0;
    }
    
    int result = search(data, n);
    printf("%d\n", result);
    
    return 0;
}

int input(int *a, int *n)
{
    if (scanf("%d", n) != 1 || *n <= 0 || *n > NMAX) {
        return 0;
    }
    for (int i = 0; i < *n; i++) {
        if (scanf("%d", &a[i]) != 1) {
            return 0;
        }
    }
    return 1;
}

double mean(int *a, int n)
{
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += a[i];
    }
    return sum / n;
}

double variance(int *a, int n)
{
    double m = mean(a, n);
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        double diff = a[i] - m;
        sum += diff * diff;
    }
    return sum / n;
}

int search(int *a, int n)
{
    double m = mean(a, n);
    double var = variance(a, n);
    double sigma = sqrt(var);
    double limit = m + 3 * sigma;
    
    for (int i = 0; i < n; i++) {
        int x = a[i];
        if (x != 0 && x % 2 == 0 && x >= m && x <= limit) {
            return x;
        }
    }
    return 0;
}