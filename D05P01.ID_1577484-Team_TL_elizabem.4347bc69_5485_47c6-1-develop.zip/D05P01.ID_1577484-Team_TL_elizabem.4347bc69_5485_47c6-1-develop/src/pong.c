#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static int ball_x = 40, ball_y = 12;
static int ball_dx = 1, ball_dy = 1;
static int left_y = 11, right_y = 11;
static int left_score = 0, right_score = 0;
static int step_mode = 1;

void clear_screen() {
    printf("\033[2J\033[H");
    fflush(stdout);
}

void draw_field() {
    clear_screen();
    
    // Верхняя граница
    for (int i = 0; i < 82; i++) printf("#");
    printf("\n");
    
    // Основное поле
    for (int y = 0; y < 25; y++) {
        printf("#");
        for (int x = 0; x < 80; x++) {
            if (x == 0 || x == 79) {
                printf("|");
            }
            else if (x == 2 && y >= left_y && y < left_y + 3) {
                printf("|");
            }
            else if (x == 76 && y >= right_y && y < right_y + 3) {
                printf("|");
            }
            else if (x == ball_x && y == ball_y) {
                printf("O");
            }
            else {
                printf(" ");
            }
        }
        printf("#\n");
    }
    
    // Нижняя граница
    for (int i = 0; i < 82; i++) printf("#");
    printf("\n");
    
    // Счёт
    printf("Left: %d          Right: %d\n", left_score, right_score);
    printf("Controls: A(down)/Z(up) | K(up)/M(down) | SPACE - next move | S - toggle mode\n");
    fflush(stdout);
}

void update_ball() {
    ball_x += ball_dx;
    ball_y += ball_dy;
    
    if (ball_y <= 0) { ball_y = 0; ball_dy = 1; }
    if (ball_y >= 24) { ball_y = 24; ball_dy = -1; }
    if (ball_x == 3 && ball_y >= left_y && ball_y < left_y + 3) ball_dx = 1;
    if (ball_x == 75 && ball_y >= right_y && ball_y < right_y + 3) ball_dx = -1;
    
    if (ball_x <= 0) {
        right_score++;
        ball_x = 40; ball_y = 12;
        ball_dx = 1; ball_dy = 1;
    }
    if (ball_x >= 79) {
        left_score++;
        ball_x = 40; ball_y = 12;
        ball_dx = -1; ball_dy = 1;
    }
}

int main() {
    char input[10];
    
    while (left_score < 21 && right_score < 21) {
        draw_field();
        
        fgets(input, sizeof(input), stdin);
        
        if (input[0] == 'a' && left_y > 0) left_y--;
        if (input[0] == 'z' && left_y < 22) left_y++;
        if (input[0] == 'k' && right_y > 0) right_y--;
        if (input[0] == 'm' && right_y < 22) right_y++;
        if (input[0] == 's') step_mode = !step_mode;
        
        if (step_mode) {
            if (input[0] == ' ') {
                update_ball();
            }
        } else {
            update_ball();
        }
    }
    
    clear_screen();
    if (left_score >= 21) {
        printf("\n\n\n\n\n\n\nLEFT PLAYER WINS!\n\n\n");
    } else {
        printf("\n\n\n\n\n\n\nRIGHT PLAYER WINS!\n\n\n");
    }
    
    return 0;
}