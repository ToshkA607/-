#ifndef STACK_H
#define STACK_H

typedef struct stack {
    int *data;
    int size;
    int capacity;
} stack;

stack *init(void);
void push(stack *s, int value);
int pop(stack *s);
void destroy(stack *s);

#endif