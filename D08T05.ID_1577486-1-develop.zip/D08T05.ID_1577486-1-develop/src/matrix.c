#include <stdio.h>
#include <stdlib.h>

#define MAX_STATIC 100

void input_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols);
void output_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols);

int** allocate_dynamic_ptr(int rows, int cols);
void free_dynamic_ptr(int** matrix, int rows);
void input_dynamic_ptr(int** matrix, int rows, int cols);
void output_dynamic_ptr(int** matrix, int rows, int cols);

int* allocate_dynamic_single(int rows, int cols);
void free_dynamic_single(int* matrix);
void input_dynamic_single(int* matrix, int rows, int cols);
void output_dynamic_single(int* matrix, int rows, int cols);

int** allocate_dynamic_segments(int rows, int cols);
void free_dynamic_segments(int** matrix, int rows);
void input_dynamic_segments(int** matrix, int rows, int cols);
void output_dynamic_segments(int** matrix, int rows, int cols);

int main() {
    int method, rows, cols;

    if (scanf("%d", &method) != 1 || method < 1 || method > 4) {
        printf("n/a");
        return 0;
    }

    if (scanf("%d %d", &rows, &cols) != 2 || rows <= 0 || cols <= 0) {
        printf("n/a");
        return 0;
    }

    if (method == 1) {
        if (rows > MAX_STATIC || cols > MAX_STATIC) {
            printf("n/a");
            return 0;
        }
        int matrix[MAX_STATIC][MAX_STATIC];
        input_static(matrix, rows, cols);
        output_static(matrix, rows, cols);
    } else if (method == 2) {
        int** matrix = allocate_dynamic_ptr(rows, cols);
        if (matrix == NULL) {
            printf("n/a");
            return 0;
        }
        input_dynamic_ptr(matrix, rows, cols);
        output_dynamic_ptr(matrix, rows, cols);
        free_dynamic_ptr(matrix, rows);
    } else if (method == 3) {
        int* matrix = allocate_dynamic_single(rows, cols);
        if (matrix == NULL) {
            printf("n/a");
            return 0;
        }
        input_dynamic_single(matrix, rows, cols);
        output_dynamic_single(matrix, rows, cols);
        free_dynamic_single(matrix);
    } else if (method == 4) {
        int** matrix = allocate_dynamic_segments(rows, cols);
        if (matrix == NULL) {
            printf("n/a");
            return 0;
        }
        input_dynamic_segments(matrix, rows, cols);
        output_dynamic_segments(matrix, rows, cols);
        free_dynamic_segments(matrix, rows);
    }

    return 0;
}

void input_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void output_static(int matrix[MAX_STATIC][MAX_STATIC], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

int** allocate_dynamic_ptr(int rows, int cols) {
    int** matrix = (int**)malloc(rows * sizeof(int*));
    if (matrix == NULL) return NULL;

    for (int i = 0; i < rows; i++) {
        matrix[i] = (int*)malloc(cols * sizeof(int));
        if (matrix[i] == NULL) {
            for (int k = 0; k < i; k++) free(matrix[k]);
            free(matrix);
            return NULL;
        }
    }
    return matrix;
}

void free_dynamic_ptr(int** matrix, int rows) {
    for (int i = 0; i < rows; i++) free(matrix[i]);
    free(matrix);
}

void input_dynamic_ptr(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void output_dynamic_ptr(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

int* allocate_dynamic_single(int rows, int cols) { return (int*)malloc(rows * cols * sizeof(int)); }

void free_dynamic_single(int* matrix) { free(matrix); }

void input_dynamic_single(int* matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i * cols + j]);
        }
    }
}

void output_dynamic_single(int* matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i * cols + j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

int** allocate_dynamic_segments(int rows, int cols) {
    int* data = (int*)malloc(rows * cols * sizeof(int));
    if (data == NULL) return NULL;

    int** matrix = (int**)malloc(rows * sizeof(int*));
    if (matrix == NULL) {
        free(data);
        return NULL;
    }

    for (int i = 0; i < rows; i++) {
        matrix[i] = data + i * cols;
    }
    return matrix;
}

void free_dynamic_segments(int** matrix, int rows) {
    (void)rows;
    if (matrix == NULL) return;
    free(matrix[0]);
    free(matrix);
}

void input_dynamic_segments(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void output_dynamic_segments(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}