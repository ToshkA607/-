#include <stdio.h>
#include <stdlib.h>

#include "bst.h"

void print_node(t_btree *node) {
    if (node == NULL) {
        printf("NULL\n");
        return;
    }
    printf("Node created: item=%d, left=%p, right=%p\n", node->item, node->left, node->right);
}

int main() {
    printf("=== bstree_create_node TEST ===\n");

    t_btree *node1 = bstree_create_node(42);
    print_node(node1);

    t_btree *node2 = bstree_create_node(7);
    print_node(node2);

    free(node1);
    free(node2);

    return 0;
}