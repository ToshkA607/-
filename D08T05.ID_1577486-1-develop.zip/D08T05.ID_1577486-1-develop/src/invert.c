#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double det(double **matrix, int n);
void get_cofactor(double **matrix, double **temp, int p, int q, int n);
void adjoint(double **matrix, double **adj, int n);
int invert(double **matrix, double **inv, int n);
void input(double ***matrix, int *n);
void output(double **matrix, int n);

int main() {
    double **matrix = NULL;
    int n;

    input(&matrix, &n);
    if (matrix == NULL) {
        printf("n/a");
        return 0;
    }

    double **inv = (double **)malloc(n * sizeof(double *));
    double *inv_data = (double *)malloc(n * n * sizeof(double));
    if (inv == NULL || inv_data == NULL) {
        printf("n/a");
        free(matrix[0]);
        free(matrix);
        return 0;
    }
    for (int i = 0; i < n; i++) {
        inv[i] = inv_data + i * n;
    }

    if (invert(matrix, inv, n) == 0) {
        printf("n/a");
    } else {
        output(inv, n);
    }

    free(matrix[0]);
    free(matrix);
    free(inv_data);
    free(inv);
    return 0;
}

double det(double **matrix, int n) {
    if (n == 1) return matrix[0][0];
    if (n == 2) {
        return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
    }

    double result = 0.0;
    double **temp = (double **)malloc((n - 1) * sizeof(double *));
    double *temp_data = (double *)malloc((n - 1) * (n - 1) * sizeof(double));
    if (temp == NULL || temp_data == NULL) return 0;

    for (int i = 0; i < n - 1; i++) {
        temp[i] = temp_data + i * (n - 1);
    }

    for (int col = 0; col < n; col++) {
        get_cofactor(matrix, temp, 0, col, n);
        double sign = (col % 2 == 0) ? 1.0 : -1.0;
        result += sign * matrix[0][col] * det(temp, n - 1);
    }

    free(temp_data);
    free(temp);
    return result;
}

void get_cofactor(double **matrix, double **temp, int p, int q, int n) {
    int i = 0, j = 0;
    for (int row = 0; row < n; row++) {
        for (int col = 0; col < n; col++) {
            if (row != p && col != q) {
                temp[i][j++] = matrix[row][col];
                if (j == n - 1) {
                    j = 0;
                    i++;
                }
            }
        }
    }
}

void adjoint(double **matrix, double **adj, int n) {
    if (n == 1) {
        adj[0][0] = 1;
        return;
    }

    double **temp = (double **)malloc((n - 1) * sizeof(double *));
    double *temp_data = (double *)malloc((n - 1) * (n - 1) * sizeof(double));
    for (int i = 0; i < n - 1; i++) {
        temp[i] = temp_data + i * (n - 1);
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            get_cofactor(matrix, temp, i, j, n);
            double sign = ((i + j) % 2 == 0) ? 1.0 : -1.0;
            adj[j][i] = sign * det(temp, n - 1);
        }
    }

    free(temp_data);
    free(temp);
}

int invert(double **matrix, double **inv, int n) {
    double d = det(matrix, n);
    if (d == 0) return 0;

    double **adj = (double **)malloc(n * sizeof(double *));
    double *adj_data = (double *)malloc(n * n * sizeof(double));
    if (adj == NULL || adj_data == NULL) return 0;

    for (int i = 0; i < n; i++) {
        adj[i] = adj_data + i * n;
    }

    adjoint(matrix, adj, n);

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            inv[i][j] = adj[i][j] / d;
        }
    }

    free(adj_data);
    free(adj);
    return 1;
}

void input(double ***matrix, int *n) {
    if (scanf("%d", n) != 1 || *n <= 0) {
        *matrix = NULL;
        return;
    }

    *matrix = (double **)malloc(*n * sizeof(double *));
    if (*matrix == NULL) return;

    double *data = (double *)malloc(*n * *n * sizeof(double));
    if (data == NULL) {
        free(*matrix);
        *matrix = NULL;
        return;
    }

    for (int i = 0; i < *n; i++) {
        (*matrix)[i] = data + i * (*n);
    }

    for (int i = 0; i < *n; i++) {
        for (int j = 0; j < *n; j++) {
            if (scanf("%lf", &(*matrix)[i][j]) != 1) {
                free(data);
                free(*matrix);
                *matrix = NULL;
                return;
            }
        }
    }
}

void output(double **matrix, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%.6f", matrix[i][j]);
            if (j < n - 1) printf(" ");
        }
        if (i < n - 1) printf("\n");
    }
}